<?php

namespace Symfony\Bundle\SampleBundle\Entity;
 
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;
 
/**
 * Article
 *
 * @ORM\Table()
 * @ORM\Entity(repositoryClass="Symfony\Bundle\SampleBundle\Entity\ArticleRepository")
 */
class Article
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;
 
    /**
     * @var string
     * @Assert\NotBlank(message="标题不可为空")
     * @Assert\Length(
     *     max=200,
     *     maxMessage="标题不能超过200个字"
     * )
     * @ORM\Column(name="title", type="string", length=200)
     */
    private $title;
 
    /**
     * @var string
     *
     * @Assert\NotBlank(message="文章内容不可为空")
     * @ORM\Column(name="content", type="text")
     */
    private $content;
 
    /**
     * @var string
     *
     * @ORM\Column(name="author", type="string", length=20,nullable=true)
     */
    private $author;
 
    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }
 
    /**
     * Set title
     *
     * @param string $title
     * @return Article
     */
    public function setTitle($title)
    {
        $this->title = $title;
 
        return $this;
    }
 
    /**
     * Get title
     *
     * @return string
     */
    public function getTitle()
    {
        return $this->title;
    }
 
    /**
     * Set content
     *
     * @param string $content
     * @return Article
     */
    public function setContent($content)
    {
        $this->content = $content;
 
        return $this;
    }
 
    /**
     * Get content
     *
     * @return string
     */
    public function getContent()
    {
        return $this->content;
    }
 
    /**
     * Set author
     *
     * @param string $author
     * @return Article
     */
    public function setAuthor($author)
    {
        $this->author = $author;
 
        return $this;
    }
 
    /**
     * Get author
     *
     * @return string
     */
    public function getAuthor()
    {
        return $this->author;
    }
}