<?php

namespace Symfony\Bundle\SampleBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class SymfonySampleBundle extends Bundle
{
}
