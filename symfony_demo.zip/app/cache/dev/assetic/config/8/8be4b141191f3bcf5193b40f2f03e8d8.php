<?php

// :blog:comment_form_error.html.twig
return array (
);
