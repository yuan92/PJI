<?php

// :admin/blog:index.html.twig
return array (
);
