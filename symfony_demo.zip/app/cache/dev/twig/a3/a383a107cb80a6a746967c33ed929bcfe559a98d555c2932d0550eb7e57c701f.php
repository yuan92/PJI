<?php

/* form/fields.html.twig */
class __TwigTemplate_13763b1edbbf9485b7a0da43d8574c563d6e889ecee86d73b8e084e94e96157f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'app_datetimepicker_widget' => array($this, 'block_app_datetimepicker_widget'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_bda18cd639055a10930b37776abba85400b837c97beef8c090b7c0496cf3d4f0 = $this->env->getExtension("native_profiler");
        $__internal_bda18cd639055a10930b37776abba85400b837c97beef8c090b7c0496cf3d4f0->enter($__internal_bda18cd639055a10930b37776abba85400b837c97beef8c090b7c0496cf3d4f0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "form/fields.html.twig"));

        // line 7
        echo "
";
        // line 8
        $this->displayBlock('app_datetimepicker_widget', $context, $blocks);
        
        $__internal_bda18cd639055a10930b37776abba85400b837c97beef8c090b7c0496cf3d4f0->leave($__internal_bda18cd639055a10930b37776abba85400b837c97beef8c090b7c0496cf3d4f0_prof);

    }

    public function block_app_datetimepicker_widget($context, array $blocks = array())
    {
        $__internal_e02d8b3034bd0865dff0265f1ef7682169c530ab4cb2a0864866092efd83043e = $this->env->getExtension("native_profiler");
        $__internal_e02d8b3034bd0865dff0265f1ef7682169c530ab4cb2a0864866092efd83043e->enter($__internal_e02d8b3034bd0865dff0265f1ef7682169c530ab4cb2a0864866092efd83043e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "app_datetimepicker_widget"));

        // line 9
        echo "    ";
        ob_start();
        // line 10
        echo "        <div class=\"input-group date\" data-toggle=\"datetimepicker\">
            ";
        // line 11
        $this->displayBlock("datetime_widget", $context, $blocks);
        echo "
            <span class=\"input-group-addon\">
                <span class=\"fa fa-calendar\"></span>
            </span>
        </div>
    ";
        echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
        
        $__internal_e02d8b3034bd0865dff0265f1ef7682169c530ab4cb2a0864866092efd83043e->leave($__internal_e02d8b3034bd0865dff0265f1ef7682169c530ab4cb2a0864866092efd83043e_prof);

    }

    public function getTemplateName()
    {
        return "form/fields.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  44 => 11,  41 => 10,  38 => 9,  26 => 8,  23 => 7,);
    }
}
/* {#*/
/*    Each field type is rendered by a template fragment, which is determined*/
/*    by the value of your getName() method and the suffix _widget.*/
/* */
/*    See http://symfony.com/doc/current/cookbook/form/create_custom_field_type.html#creating-a-template-for-the-field*/
/* #}*/
/* */
/* {% block app_datetimepicker_widget %}*/
/*     {% spaceless %}*/
/*         <div class="input-group date" data-toggle="datetimepicker">*/
/*             {{ block('datetime_widget') }}*/
/*             <span class="input-group-addon">*/
/*                 <span class="fa fa-calendar"></span>*/
/*             </span>*/
/*         </div>*/
/*     {% endspaceless %}*/
/* {% endblock %}*/
/* */
