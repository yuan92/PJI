<?php

/* default/homepage.html.twig */
class __TwigTemplate_4b0e9b1cfbcd2477487b0ed2342b94586accf4e34f6c3cf460af07b22fe80ca9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "default/homepage.html.twig", 1);
        $this->blocks = array(
            'body_id' => array($this, 'block_body_id'),
            'header' => array($this, 'block_header'),
            'footer' => array($this, 'block_footer'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_eca81dbaebaf4356acb08984f7db811be38e8625e8be528d581abe8efbfdd08d = $this->env->getExtension("native_profiler");
        $__internal_eca81dbaebaf4356acb08984f7db811be38e8625e8be528d581abe8efbfdd08d->enter($__internal_eca81dbaebaf4356acb08984f7db811be38e8625e8be528d581abe8efbfdd08d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "default/homepage.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_eca81dbaebaf4356acb08984f7db811be38e8625e8be528d581abe8efbfdd08d->leave($__internal_eca81dbaebaf4356acb08984f7db811be38e8625e8be528d581abe8efbfdd08d_prof);

    }

    // line 3
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_918c344dc7acbf364a98305c0665f87b5a3eabd3a99f585ee368298eb78c16c0 = $this->env->getExtension("native_profiler");
        $__internal_918c344dc7acbf364a98305c0665f87b5a3eabd3a99f585ee368298eb78c16c0->enter($__internal_918c344dc7acbf364a98305c0665f87b5a3eabd3a99f585ee368298eb78c16c0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        echo "homepage";
        
        $__internal_918c344dc7acbf364a98305c0665f87b5a3eabd3a99f585ee368298eb78c16c0->leave($__internal_918c344dc7acbf364a98305c0665f87b5a3eabd3a99f585ee368298eb78c16c0_prof);

    }

    // line 9
    public function block_header($context, array $blocks = array())
    {
        $__internal_337cdd5477dd7ada38cbe0d56d060484bf61471be49c00b4c7fed097def5c7be = $this->env->getExtension("native_profiler");
        $__internal_337cdd5477dd7ada38cbe0d56d060484bf61471be49c00b4c7fed097def5c7be->enter($__internal_337cdd5477dd7ada38cbe0d56d060484bf61471be49c00b4c7fed097def5c7be_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header"));

        
        $__internal_337cdd5477dd7ada38cbe0d56d060484bf61471be49c00b4c7fed097def5c7be->leave($__internal_337cdd5477dd7ada38cbe0d56d060484bf61471be49c00b4c7fed097def5c7be_prof);

    }

    // line 10
    public function block_footer($context, array $blocks = array())
    {
        $__internal_f40a0435dabd578a89cfd255a33a4fe17ebbc8a3450290ad7f897ef2601e3076 = $this->env->getExtension("native_profiler");
        $__internal_f40a0435dabd578a89cfd255a33a4fe17ebbc8a3450290ad7f897ef2601e3076->enter($__internal_f40a0435dabd578a89cfd255a33a4fe17ebbc8a3450290ad7f897ef2601e3076_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "footer"));

        
        $__internal_f40a0435dabd578a89cfd255a33a4fe17ebbc8a3450290ad7f897ef2601e3076->leave($__internal_f40a0435dabd578a89cfd255a33a4fe17ebbc8a3450290ad7f897ef2601e3076_prof);

    }

    // line 12
    public function block_body($context, array $blocks = array())
    {
        $__internal_218c47fbac4ed2236f35873eb9f77f38b26bf043d700cb0fd8f890ed44993483 = $this->env->getExtension("native_profiler");
        $__internal_218c47fbac4ed2236f35873eb9f77f38b26bf043d700cb0fd8f890ed44993483->enter($__internal_218c47fbac4ed2236f35873eb9f77f38b26bf043d700cb0fd8f890ed44993483_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 13
        echo "    <div class=\"page-header\">
        <h1>";
        // line 14
        echo $this->env->getExtension('translator')->trans("title.homepage");
        echo "</h1>
    </div>

    <div class=\"row\">
        <div class=\"col-sm-6\">
            <div class=\"jumbotron\">
                <p>
                    ";
        // line 21
        echo $this->env->getExtension('translator')->trans("help.browse_app");
        echo "
                </p>
                <p>
                    <a class=\"btn btn-primary btn-lg\" href=\"";
        // line 24
        echo $this->env->getExtension('routing')->getPath("blog_index");
        echo "\">
                        <i class=\"fa fa-users\"></i> ";
        // line 25
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("action.browse_app"), "html", null, true);
        echo "
                    </a>
                </p>
            </div>
        </div>

        <div class=\"col-sm-6\">
            <div class=\"jumbotron\">
                <p>
                    ";
        // line 34
        echo $this->env->getExtension('translator')->trans("help.browse_admin");
        echo "
                </p>
                <p>
                    <a class=\"btn btn-primary btn-lg\" href=\"";
        // line 37
        echo $this->env->getExtension('routing')->getPath("admin_index");
        echo "\">
                        <i class=\"fa fa-lock\"></i> ";
        // line 38
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("action.browse_admin"), "html", null, true);
        echo "
                    </a>
                </p>
            </div>
        </div>
    </div>
";
        
        $__internal_218c47fbac4ed2236f35873eb9f77f38b26bf043d700cb0fd8f890ed44993483->leave($__internal_218c47fbac4ed2236f35873eb9f77f38b26bf043d700cb0fd8f890ed44993483_prof);

    }

    public function getTemplateName()
    {
        return "default/homepage.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  122 => 38,  118 => 37,  112 => 34,  100 => 25,  96 => 24,  90 => 21,  80 => 14,  77 => 13,  71 => 12,  60 => 10,  49 => 9,  37 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block body_id 'homepage' %}*/
/* */
/* {#*/
/*     the homepage is a special page which displays neither a header nor a footer.*/
/*     this is done with the 'trick' of defining empty Twig blocks without any content*/
/* #}*/
/* {% block header %}{% endblock %}*/
/* {% block footer %}{% endblock %}*/
/* */
/* {% block body %}*/
/*     <div class="page-header">*/
/*         <h1>{{ 'title.homepage'|trans|raw }}</h1>*/
/*     </div>*/
/* */
/*     <div class="row">*/
/*         <div class="col-sm-6">*/
/*             <div class="jumbotron">*/
/*                 <p>*/
/*                     {{ 'help.browse_app'|trans|raw }}*/
/*                 </p>*/
/*                 <p>*/
/*                     <a class="btn btn-primary btn-lg" href="{{ path('blog_index') }}">*/
/*                         <i class="fa fa-users"></i> {{ 'action.browse_app'|trans }}*/
/*                     </a>*/
/*                 </p>*/
/*             </div>*/
/*         </div>*/
/* */
/*         <div class="col-sm-6">*/
/*             <div class="jumbotron">*/
/*                 <p>*/
/*                     {{ 'help.browse_admin'|trans|raw }}*/
/*                 </p>*/
/*                 <p>*/
/*                     <a class="btn btn-primary btn-lg" href="{{ path('admin_index') }}">*/
/*                         <i class="fa fa-lock"></i> {{ 'action.browse_admin'|trans }}*/
/*                     </a>*/
/*                 </p>*/
/*             </div>*/
/*         </div>*/
/*     </div>*/
/* {% endblock %}*/
/* */
